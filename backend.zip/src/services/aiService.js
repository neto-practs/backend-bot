const logger = require("../utils/logger");
const { getSystemPrompt } = require("../config/prompts");
const apiRepository = require("../repositories/apiRepository");
const cacheService = require("./cacheService");
const { formatearParaReact } = require("../utils/formateadorPiezasReact");
const { generarClaveCache } = require("../utils/cacheKeyGenerator");
const { seleccionRespuesta } = require("./chatService");

//Configuración desde el .ENV
const RUNPOD_IA_URL = process.env.RUNPOD_IA_URL;
const RUNPOD_IA_TOKEN = process.env.RUNPOD_IA_TOKEN;
const RUNPOD_IA_MODEL = process.env.RUNPOD_IA_MODEL;
const AI_TEMPERATURE = parseFloat(process.env.RUNPOD_AI_TEMPERATURE) || 0.2;
const AI_MAX_TOKENS = parseInt(process.env.RUNPOD_AI_MAX_TOKENS) || 200;
const STORE_BASE_URL = process.env.STORE_BASE_URL;
const LIMITE_GENERICO = process.env.LIMITE_GENERICO || 500;

/**
 * Función principal que realiza la llamada directa a la IA (Compatible con OpenAI)
 * @param {string} promptUsuario - El mensaje que le enviaremos a la IA
 * @param {string} reqId - (Opcional) ID de petición para los logs informativos
 * @param {string} contextoAnterior - Memoria enviada desde el FrontEnd
 */
const seleccionRespuestaPremium = async (promptUsuario, contextoAnterior = "", reqId = "test") => {

  try{
    logger.info({ reqId }, `Iniciando peticion a vLLM (Modelo: ${RUNPOD_IA_MODEL})...`);

    const promptDelSistema = getSystemPrompt(STORE_BASE_URL, contextoAnterior);

    const response = await fetch(RUNPOD_IA_URL, {
      method: "POST",
      headers: {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${RUNPOD_IA_TOKEN}`,
      },
      body: JSON.stringify({ 
        model: RUNPOD_IA_MODEL,
        messages: [
          { role: "system", content: promptDelSistema },
          { role: "user", content: promptUsuario }
        ],
        temperature: AI_TEMPERATURE,
        max_tokens: AI_MAX_TOKENS
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`vLLM fallo: HTTP ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    //Ruta a modificar según los campos de respuesta del bot
    const textoFinal = data.choices[0].message.content.trim();

    let mensajeParaUsuario = textoFinal;
    let busquedaBD = null;

    // Extracción Inteligente del Intent (JSON)
    if (textoFinal.includes("<SEARCH_INTENT>")) {
      // Esta regex captura el JSON { ... } incluso si la IA olvida cerrar el </SEARCH_INTENT>
      const match = textoFinal.match(/<SEARCH_INTENT>\s*(\{[\s\S]*?\})/);
      
      if (match) {
        try { 
          busquedaBD = JSON.parse(match[1].trim());
          
          // Limpiamos el mensaje: Borramos desde el <SEARCH_INTENT> hasta el final del texto
          mensajeParaUsuario = textoFinal.replace(/<SEARCH_INTENT>[\s\S]*/, "").trim();
        } catch (e) {
          logger.error({ reqId, err: e }, "La IA generó un JSON inválido en el Search Intent.");
        }
      }
    }

    logger.info({ reqId, intentExtraido: !!busquedaBD }, `IA respondió con éxito.`);

    // --- LÓGICA DEL INTERRUPTOR DE LA IA ---
    let quiereBuscar = false;
    
    if (busquedaBD) {
      // Leemos si la IA nos ha dado luz verde para buscar
      quiereBuscar = busquedaBD.realizar_busqueda === true;
      
      const tieneTridente = busquedaBD.articulo && busquedaBD.marca && busquedaBD.modelo;
      const tieneReferencia = !!busquedaBD.referencia;

      if (tieneTridente || tieneReferencia) {
        quiereBuscar = true; 
      }
      
      if (quiereBuscar && !busquedaBD.referencia && (!busquedaBD.marca || !busquedaBD.modelo)) {
        logger.warn({ reqId }, "La IA intentó buscar sin marca/modelo. Bloqueando petición masiva a la DB.");
        quiereBuscar = false; 
        
        if (!mensajeParaUsuario || mensajeParaUsuario.trim() === "") {
          mensajeParaUsuario = `Para poder buscar tu ${busquedaBD.articulo || 'pieza'}, necesito que me indiques la marca y el modelo de tu vehículo.`;
        }
      }

      delete busquedaBD.realizar_busqueda; 
      delete busquedaBD._razonamiento;
    }

    // FASE 1: Faltan datos o la IA ha decidido que es una charla normal
    if (!busquedaBD || !quiereBuscar) {
      return {
        respuesta: mensajeParaUsuario,
        piezas: [],
        nuevoContexto: busquedaBD ? JSON.stringify(busquedaBD) : contextoAnterior
      };
    }

    // FASE 2: Hay datos suficientes Y la IA puso realizar_busqueda en TRUE
    const query = Object.values(busquedaBD).filter(val => val !== null && val !== "null" && val !== "").join(" ");

    const cacheKey = generarClaveCache({ q: query });
    const datosCache = cacheService.obtenerDeCache(cacheKey);

    if (datosCache) {
      logger.info({ reqId }, "[Premium] Sirviendo piezas directamente desde la caché local.");
      datosCache.respuesta = mensajeParaUsuario;
      datosCache.nuevoContexto = JSON.stringify(busquedaBD);
      return datosCache;
    }
    //Si no está en CACHE, lanzamos a la API la peticion
    const respuestaAPI = await apiRepository.consultarAPI({ q: query }, reqId);

    let resultadoFinal;

    if (!respuestaAPI.piezas || respuestaAPI.piezas.length === 0) {
      //  Si no hay stock, ignoramos a la IA (mensajeParaUsuario) 
      
      const cocheDesc = [busquedaBD.marca, busquedaBD.modelo, busquedaBD.ano].filter(Boolean).join(" ");
      const piezaDesc = busquedaBD.articulo || "esta pieza";

      resultadoFinal = {
        respuesta: `He revisado nuestro almacén buscando "${piezaDesc}" para "${cocheDesc}". Lamentablemente, no nos queda stock disponible en este momento.\n\n¿Te puedo ayudar a buscar algún otro recambio?`,
        piezas: [],
        nuevoContexto: JSON.stringify(busquedaBD)
      };
    } else { 
      // Formateamos para el Frontend
      const total = parseInt(respuestaAPI.total) || respuestaAPI.piezas.length;
      const piezasTop = respuestaAPI.piezas.slice(0, 4);
      const excedeLimite = total > LIMITE_GENERICO;

      resultadoFinal = {
        respuesta: mensajeParaUsuario,
        piezas: formatearParaReact(piezasTop),
        metadata: { 
          totalReal: total, 
          queryLimpia: query, 
          excedeLimite: excedeLimite 
        },
        nuevoContexto: JSON.stringify(busquedaBD) // Metemos el JSON en la mochila del Front
      };
    }
    cacheService.guardarEnCache(cacheKey, resultadoFinal);
    return resultadoFinal;

    
  } catch (error) {
    logger.error({ reqId, err: error }, `Error crítico en aiService: ${error.message}`);
    return null;
  }
};

module.exports = { seleccionRespuestaPremium };